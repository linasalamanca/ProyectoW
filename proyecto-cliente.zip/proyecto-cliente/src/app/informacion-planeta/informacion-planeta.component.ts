import { Component } from '@angular/core';

@Component({
  selector: 'app-informacion-planeta',
  standalone: true,
  imports: [],
  templateUrl: './informacion-planeta.component.html',
  styleUrl: './informacion-planeta.component.css'
})
export class InformacionPlanetaComponent {

}
