import { Component } from '@angular/core';

@Component({
  selector: 'app-seleccionar-planeta',
  standalone: true,
  imports: [],
  templateUrl: './seleccionar-planeta.component.html',
  styleUrl: './seleccionar-planeta.component.css'
})
export class SeleccionarPlanetaComponent {

}
