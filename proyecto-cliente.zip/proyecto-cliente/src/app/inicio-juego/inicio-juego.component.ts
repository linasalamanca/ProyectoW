import { Component } from '@angular/core';

@Component({
  selector: 'app-inicio-juego',
  standalone: true,
  imports: [],
  templateUrl: './inicio-juego.component.html',
  styleUrl: './inicio-juego.component.css'
})
export class InicioJuegoComponent {

}
