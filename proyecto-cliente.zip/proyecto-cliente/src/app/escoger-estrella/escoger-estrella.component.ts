import { Component } from '@angular/core';

@Component({
  selector: 'app-escoger-estrella',
  standalone: true,
  imports: [],
  templateUrl: './escoger-estrella.component.html',
  styleUrl: './escoger-estrella.component.css'
})
export class EscogerEstrellaComponent {

}
