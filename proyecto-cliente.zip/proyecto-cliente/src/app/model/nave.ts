export class Nave {

    constructor(
        public nombre: string,
        public dinero: number,
        public coordenadaX: number,
        public coordenadaY: number,
        public coordenadaZ: number,
        public tiempo: number,
    ) { }
}