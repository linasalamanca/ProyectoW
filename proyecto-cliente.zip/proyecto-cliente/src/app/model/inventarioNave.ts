export class InventarioNave {

    constructor(
        public id: number,
        public cantidad: number,
    ) { }
}