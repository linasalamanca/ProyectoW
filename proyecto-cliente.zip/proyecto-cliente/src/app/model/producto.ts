export class Producto {

    constructor(
        public id: number,
        public volumen: number,
        public tipo: string,
    ) { }
}