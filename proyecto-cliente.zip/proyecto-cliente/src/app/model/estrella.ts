export class Estrella {

    constructor(
        public id: number,
        public coordenadaX: number,
        public coordenadaY: number,
        public coordenadaZ: number,
    ) { }
}