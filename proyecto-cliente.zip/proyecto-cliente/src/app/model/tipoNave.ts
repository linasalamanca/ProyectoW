export class TipoNave {

    constructor(
        public id: number,
        public nombre: string,
        public volumenCarga: number,
        public velocidad: number,
    ) { }
}