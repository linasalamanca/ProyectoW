export class InventarioPlaneta {

    constructor(
        public id: number,
        public cantidad: number,
        public fOfertaDemanda: number,
    ) { }
}