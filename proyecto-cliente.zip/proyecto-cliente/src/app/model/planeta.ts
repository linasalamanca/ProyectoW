export class Planeta {

    constructor(
        public id: number,
        public nombre: string,
    ) { }
}