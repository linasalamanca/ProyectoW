export class Jugador {

    constructor(
        public id: number,
        public rol: string,
        public usuario: string,
        public contrasena: string,
    ) { }
}