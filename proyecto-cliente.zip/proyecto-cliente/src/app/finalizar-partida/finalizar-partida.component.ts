import { Component } from '@angular/core';

@Component({
  selector: 'app-finalizar-partida',
  standalone: true,
  imports: [],
  templateUrl: './finalizar-partida.component.html',
  styleUrl: './finalizar-partida.component.css'
})
export class FinalizarPartidaComponent {

}
