import { Component } from '@angular/core';

@Component({
  selector: 'app-vender',
  standalone: true,
  imports: [],
  templateUrl: './vender.component.html',
  styleUrl: './vender.component.css'
})
export class VenderComponent {

}
