import { Component } from '@angular/core';

@Component({
  selector: 'app-conprar',
  standalone: true,
  imports: [],
  templateUrl: './conprar.component.html',
  styleUrl: './conprar.component.css'
})
export class ConprarComponent {

}
